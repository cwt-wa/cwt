<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
       "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>
    <title>CWT 2010</title>
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
    <meta name="keywords" content="CWT, Crespos Worms Tournament, Worms Armageddon, worms tourney, worms tournament, Normal No Noobs">
    <meta name="description" content="Crespo's Worms Tournament is a Worms Armageddon tournament organized since 2002! Once a year the best wormers come together to play in a friendly atmosphere and finally find their best.">
    <meta name="robots" content="all">
    <meta name="author" content="Zemke">
    <style>
        body, html {
            background-image: url(whole.png);
            background-repeat: repeat;
        }

        #content {
            font-family: Tahoma;
            color: white;
            text-align: center;

            padding-top: 150px;
            padding-bottom: 0px;
        }

        .head {
            font-size: 20pt;
            font-weight: bold;
        }
    </style>
</head>

<body>
<div id="content">

<table align="center">
    <tr>
        <td><span class="head">Crespo's Worms Tournament 2010</span></td>
    </tr>
    <tr>
        <td align="right"><i>by Joschi, Random00 and Zemke</i></td>
    </tr>
    <tr>
        <td height="70" valign="bottom" align="center"><img src="working.png" alt="Working" title="Working"></td>
    </tr>
    <tr>
        <td height="70" valign="bottom" align="center"><font color="red">The opening of the site has been delayed. We will be back by the 1st October at the latest.<br>If the delay causes any problems to you we take care of you! support@cwtsite.com</font><br>Visit our <a href="http://crespo2003.proboards.com/index.cgi?board=talkhere" target="_blank">forum</a> for more information.</td>
    </tr>
</table>

</div>
</body>

</html>