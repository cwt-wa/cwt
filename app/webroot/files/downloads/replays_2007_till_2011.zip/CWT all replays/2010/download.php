<?php

$filename = $_GET['filename'];
$security = substr($filename, strlen($filename)-7); // Returns the last seven letters of $filename which are supposed to be ".WAgame".

if($security != '.WAgame')
{
    echo 'The file does not seem to be a *.WAgame file.';
    exit;
}

header('Content-type: application/wa-replay');
header("Content-Disposition: attachment; filename=\"$filename\"");

readfile($filename);

?>