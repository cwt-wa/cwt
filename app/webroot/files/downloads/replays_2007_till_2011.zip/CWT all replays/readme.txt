There have been no replays before 2007. Replays from later than 2011 can be downloaded from www.cwtsite.ocm/archive
